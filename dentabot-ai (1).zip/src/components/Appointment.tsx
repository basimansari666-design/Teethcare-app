import React, { useState, useEffect } from 'react';
import { Calendar, Clock, MapPin, Phone, Mail, CheckCircle2, AlertCircle } from 'lucide-react';

interface AppointmentProps {
  preselectedService: string;
}

interface FormValues {
  fullName: string;
  email: string;
  phone: string;
  service: string;
  preferredDate: string;
  preferredTime: string;
  message: string;
}

interface FormErrors {
  fullName?: string;
  email?: string;
  phone?: string;
  service?: string;
  preferredDate?: string;
  preferredTime?: string;
}

const SERVICE_OPTIONS = [
  'AI Dental Scan',
  'Smart Diagnosis',
  'Digital Smile Design',
  'AI Dental Consultation',
];

const TIME_SLOTS = [
  '09:00 AM',
  '10:30 AM',
  '01:00 PM',
  '02:30 PM',
  '04:00 PM',
  '05:30 PM',
];

export const Appointment: React.FC<AppointmentProps> = ({
  preselectedService,
}) => {
  const defaultDate = '2026-10-12';

  const [values, setValues] = useState<FormValues>({
    fullName: '',
    email: '',
    phone: '',
    service: preselectedService || 'AI Dental Scan',
    preferredDate: defaultDate,
    preferredTime: '10:30 AM',
    message: '',
  });

  const [errors, setErrors] = useState<FormErrors>({});
  const [submittedBooking, setSubmittedBooking] = useState<(FormValues & { referenceCode: string }) | null>(null);

  useEffect(() => {
    if (preselectedService) {
      setValues((prev) => ({ ...prev, service: preselectedService }));
    }
  }, [preselectedService]);

  const validate = (): FormErrors => {
    const newErrors: FormErrors = {};
    if (!values.fullName.trim() || values.fullName.trim().length < 2) {
      newErrors.fullName = 'Please enter your full name.';
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!values.email.trim() || !emailRegex.test(values.email.trim())) {
      newErrors.email = 'Please enter a valid email address.';
    }
    const phoneDigits = values.phone.replace(/\D/g, '');
    if (!values.phone.trim() || phoneDigits.length < 7) {
      newErrors.phone = 'Please enter a valid phone number (at least 7 digits).';
    }
    if (!values.service) {
      newErrors.service = 'Please select a dental service.';
    }
    if (!values.preferredDate) {
      newErrors.preferredDate = 'Please select a preferred appointment date.';
    }
    if (!values.preferredTime) {
      newErrors.preferredTime = 'Please select a preferred appointment time.';
    }
    return newErrors;
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setValues((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormErrors]) {
      setErrors((prev) => ({ ...prev, [name]: undefined }));
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const validationErrors = validate();
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    const randomNum = Math.floor(100000 + Math.random() * 900000);
    setSubmittedBooking({
      ...values,
      referenceCode: `TC-${randomNum}`,
    });
  };

  return (
    <section
      id="appointment"
      className="py-20 sm:py-28 relative bg-gradient-to-b from-[#EAF6F4] via-[#E2F2EF] to-[#F4FAF9]"
    >
      {/* Anchor alias for #contact navigation link */}
      <div id="contact" className="absolute -top-24" aria-hidden="true" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="rounded-3xl bg-white/85 backdrop-blur-xl border border-white/95 shadow-[0_25px_75px_-15px_rgba(15,118,110,0.16)] p-6 sm:p-10 lg:p-14">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
            {/* Left Column: CTA Heading, Clinical Details & Direct Contact Info */}
            <div className="lg:col-span-5">
              <p className="text-xs font-semibold tracking-wider text-[#0F766E] mb-3">
                Online Consultation Scheduling
              </p>
              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#062925] leading-[1.1] mb-4">
                Ready for a Smarter Smile?
              </h2>
              <p className="text-base sm:text-lg text-slate-600 leading-relaxed mb-8">
                Book your consultation and experience the future of modern dentistry.
              </p>

              {/* Clinical Location & Contact Details */}
              <div className="space-y-5 pt-6 border-t border-teal-100">
                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center text-[#0F766E] shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-[#062925]">
                      TeethCare Flagship Medical Center
                    </div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      450 Innovation Way, Suite 800 · San Francisco, CA 94107
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center text-[#0F766E] shrink-0">
                    <Phone className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-[#062925] tabular-nums">
                      +1 (800) 555-3368
                    </div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      Mon – Sat: 8:00 AM – 7:00 PM · 24/7 AI Triage Line
                    </div>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center text-[#0F766E] shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-sm font-bold text-[#062925]">
                      care@teethcare.com
                    </div>
                    <div className="text-xs text-slate-600 mt-0.5">
                      Direct clinical concierge & digital scan transfer
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Appointment Form or Professional Confirmation Message */}
            <div className="lg:col-span-7">
              {submittedBooking ? (
                <div
                  role="status"
                  aria-live="polite"
                  className="rounded-2xl bg-gradient-to-b from-teal-50/90 to-white border border-teal-300/80 p-7 sm:p-9 shadow-[0_14px_40px_-10px_rgba(15,118,110,0.18)]"
                >
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#115E59] to-[#0D9488] text-white flex items-center justify-center mb-6 shadow-[0_8px_20px_rgba(15,118,110,0.35)]">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>

                  <div className="text-xs font-mono font-semibold text-[#0F766E] mb-1 tabular-nums">
                    CONFIRMATION CODE: {submittedBooking.referenceCode}
                  </div>
                  <h3 className="text-2xl sm:text-3xl font-bold text-[#062925] mb-3">
                    Your Appointment Request Is Confirmed
                  </h3>
                  <p className="text-sm sm:text-base text-slate-600 leading-relaxed mb-6">
                    Thank you, <span className="font-semibold text-[#062925]">{submittedBooking.fullName}</span>. Our AI clinical coordinator has reserved your diagnostic suite and sent a calendar invitation to <span className="font-semibold text-[#062925]">{submittedBooking.email}</span>.
                  </p>

                  <div className="rounded-xl bg-white border border-teal-100 p-5 mb-7 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <span className="text-slate-400 block mb-0.5">Selected Service</span>
                      <span className="font-bold text-[#062925] text-sm">{submittedBooking.service}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-0.5">Date & Time</span>
                      <span className="font-bold text-[#062925] text-sm tabular-nums">
                        {submittedBooking.preferredDate} at {submittedBooking.preferredTime}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-0.5">Patient Phone</span>
                      <span className="font-medium text-slate-700 tabular-nums">{submittedBooking.phone}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block mb-0.5">Clinical Preparation</span>
                      <span className="font-medium text-[#0F766E]">3D Optical Scanner Pre-Calibrated</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-4">
                    <button
                      type="button"
                      onClick={() => setSubmittedBooking(null)}
                      className="px-6 py-3 text-sm font-semibold text-[#0F766E] bg-teal-50 hover:bg-teal-100 rounded-full transition-colors cursor-pointer"
                    >
                      Modify or Book Another Visit
                    </button>
                  </div>
                </div>
              ) : (
                <form
                  onSubmit={handleSubmit}
                  noValidate
                  className="rounded-2xl bg-white border border-teal-100/90 p-6 sm:p-8 shadow-[0_12px_36px_-12px_rgba(15,118,110,0.08)] space-y-5"
                >
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Full Name */}
                    <div>
                      <label
                        htmlFor="fullName"
                        className="block text-xs font-semibold text-slate-700 mb-1.5"
                      >
                        Full Name *
                      </label>
                      <input
                        id="fullName"
                        name="fullName"
                        type="text"
                        value={values.fullName}
                        onChange={handleChange}
                        placeholder="Dr. / Ms. / Mr. Alex Rivera"
                        className={`w-full rounded-xl border px-4 py-3 text-sm text-[#062925] placeholder:text-slate-400 focus:outline-none focus:ring-2 transition-colors ${
                          errors.fullName
                            ? 'border-rose-400 focus:ring-rose-500/30 bg-rose-50/30'
                            : 'border-teal-200/90 focus:border-[#0F766E] focus:ring-teal-500/20 bg-teal-50/30'
                        }`}
                      />
                      {errors.fullName && (
                        <p role="alert" className="mt-1.5 text-xs text-rose-600 flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                          <span>{errors.fullName}</span>
                        </p>
                      )}
                    </div>

                    {/* Email */}
                    <div>
                      <label
                        htmlFor="email"
                        className="block text-xs font-semibold text-slate-700 mb-1.5"
                      >
                        Email *
                      </label>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        value={values.email}
                        onChange={handleChange}
                        placeholder="alex.rivera@example.com"
                        className={`w-full rounded-xl border px-4 py-3 text-sm text-[#062925] placeholder:text-slate-400 focus:outline-none focus:ring-2 transition-colors ${
                          errors.email
                            ? 'border-rose-400 focus:ring-rose-500/30 bg-rose-50/30'
                            : 'border-teal-200/90 focus:border-[#0F766E] focus:ring-teal-500/20 bg-teal-50/30'
                        }`}
                      />
                      {errors.email && (
                        <p role="alert" className="mt-1.5 text-xs text-rose-600 flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                          <span>{errors.email}</span>
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Phone */}
                    <div>
                      <label
                        htmlFor="phone"
                        className="block text-xs font-semibold text-slate-700 mb-1.5"
                      >
                        Phone *
                      </label>
                      <input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={values.phone}
                        onChange={handleChange}
                        placeholder="+1 (555) 234-5678"
                        className={`w-full rounded-xl border px-4 py-3 text-sm text-[#062925] placeholder:text-slate-400 focus:outline-none focus:ring-2 transition-colors ${
                          errors.phone
                            ? 'border-rose-400 focus:ring-rose-500/30 bg-rose-50/30'
                            : 'border-teal-200/90 focus:border-[#0F766E] focus:ring-teal-500/20 bg-teal-50/30'
                        }`}
                      />
                      {errors.phone && (
                        <p role="alert" className="mt-1.5 text-xs text-rose-600 flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                          <span>{errors.phone}</span>
                        </p>
                      )}
                    </div>

                    {/* Select Service */}
                    <div>
                      <label
                        htmlFor="service"
                        className="block text-xs font-semibold text-slate-700 mb-1.5"
                      >
                        Select Service *
                      </label>
                      <select
                        id="service"
                        name="service"
                        value={values.service}
                        onChange={handleChange}
                        className="w-full rounded-xl border border-teal-200/90 bg-teal-50/30 px-4 py-3 text-sm text-[#062925] focus:outline-none focus:border-[#0F766E] focus:ring-2 focus:ring-teal-500/20 transition-colors"
                      >
                        {SERVICE_OPTIONS.map((option) => (
                          <option key={option} value={option}>
                            {option}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Preferred Date */}
                    <div>
                      <label
                        htmlFor="preferredDate"
                        className="block text-xs font-semibold text-slate-700 mb-1.5"
                      >
                        Preferred Date *
                      </label>
                      <div className="relative">
                        <input
                          id="preferredDate"
                          name="preferredDate"
                          type="date"
                          value={values.preferredDate}
                          onChange={handleChange}
                          className={`w-full rounded-xl border px-4 py-3 text-sm text-[#062925] tabular-nums focus:outline-none focus:ring-2 transition-colors ${
                            errors.preferredDate
                              ? 'border-rose-400 focus:ring-rose-500/30 bg-rose-50/30'
                              : 'border-teal-200/90 focus:border-[#0F766E] focus:ring-teal-500/20 bg-teal-50/30'
                          }`}
                        />
                      </div>
                      {errors.preferredDate && (
                        <p role="alert" className="mt-1.5 text-xs text-rose-600 flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                          <span>{errors.preferredDate}</span>
                        </p>
                      )}
                    </div>

                    {/* Preferred Time */}
                    <div>
                      <label
                        htmlFor="preferredTime"
                        className="block text-xs font-semibold text-slate-700 mb-1.5"
                      >
                        Preferred Time *
                      </label>
                      <div className="relative">
                        <select
                          id="preferredTime"
                          name="preferredTime"
                          value={values.preferredTime}
                          onChange={handleChange}
                          className="w-full rounded-xl border border-teal-200/90 bg-teal-50/30 px-4 py-3 text-sm text-[#062925] tabular-nums focus:outline-none focus:border-[#0F766E] focus:ring-2 focus:ring-teal-500/20 transition-colors"
                        >
                          {TIME_SLOTS.map((slot) => (
                            <option key={slot} value={slot}>
                              {slot}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Message */}
                  <div>
                    <label
                      htmlFor="message"
                      className="block text-xs font-semibold text-slate-700 mb-1.5"
                    >
                      Message (Optional)
                    </label>
                    <textarea
                      id="message"
                      name="message"
                      rows={3}
                      value={values.message}
                      onChange={handleChange}
                      placeholder="Share any dental goals, sensitivities, or questions for your AI specialist team..."
                      className="w-full rounded-xl border border-teal-200/90 bg-teal-50/30 px-4 py-3 text-sm text-[#062925] placeholder:text-slate-400 focus:outline-none focus:border-[#0F766E] focus:ring-2 focus:ring-teal-500/20 transition-colors resize-none"
                    />
                  </div>

                  <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <button
                      type="submit"
                      className="w-full sm:w-auto px-8 py-4 text-base font-semibold text-white bg-gradient-to-r from-[#115E59] via-[#0F766E] to-[#0D9488] hover:from-[#0F766E] hover:to-[#14B8A6] rounded-full shadow-[0_10px_28px_-4px_rgba(15,118,110,0.5)] hover:shadow-[0_14px_34px_-3px_rgba(13,148,136,0.65)] transition-all duration-150 whitespace-nowrap cursor-pointer active:scale-[0.99]"
                    >
                      Book Appointment
                    </button>

                    <div className="flex items-center gap-3 text-xs text-slate-500">
                      <span className="inline-flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-[#0F766E]" />
                        Instant Confirmation
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="inline-flex items-center gap-1">
                        <Clock className="w-3.5 h-3.5 text-[#0F766E]" />
                        Zero Wait Guarantee
                      </span>
                    </div>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
