import React from 'react';
import { Star } from 'lucide-react';

interface TestimonialItem {
  quote: string;
  name: string;
  initials: string;
  role: string;
  procedure: string;
  date: string;
}

const TESTIMONIALS: TestimonialItem[] = [
  {
    quote:
      'An incredibly modern experience. The AI assessment made everything easy to understand.',
    name: 'Sarah Mitchell',
    initials: 'SM',
    role: 'Product Architect',
    procedure: 'AI Dental Scan & Smart Diagnosis',
    date: 'Verified Patient · Zurich & San Francisco',
  },
  {
    quote:
      'The clinic feels futuristic but still warm and welcoming.',
    name: 'Daniel Carter',
    initials: 'DC',
    role: 'Aerospace Systems Director',
    procedure: 'Digital Smile Design',
    date: 'Verified Patient · Restorative Care',
  },
  {
    quote:
      'The technology and professional dental team made me feel completely comfortable.',
    name: 'Emily Johnson',
    initials: 'EJ',
    role: 'Clinical Research Fellow',
    procedure: 'AI Dental Consultation & Preventive Care',
    date: 'Verified Patient · Optical Tomography',
  },
];

export const Testimonials: React.FC = () => {
  return (
    <section className="py-20 sm:py-28 relative bg-gradient-to-b from-[#F4FAF9] via-white to-[#EAF6F4]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <p className="text-xs font-semibold tracking-wider text-[#0F766E] mb-3">
            Patient Experience · 4.9/5 Average Clinical Satisfaction
          </p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#062925] mb-4">
            Patients Deserve Smarter Dental Care.
          </h2>
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Real feedback from patients who experienced transparent AI diagnostics and painless specialist care at TeethCare.
          </p>
        </div>

        {/* 3 Testimonial Cards with Elegant Initials Avatars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-7">
          {TESTIMONIALS.map((item) => (
            <article
              key={item.name}
              className="rounded-2xl bg-white/85 backdrop-blur-md border border-teal-100/90 p-7 shadow-[0_12px_35px_-12px_rgba(15,118,110,0.1)] hover:shadow-[0_18px_45px_-12px_rgba(15,118,110,0.18)] hover:border-teal-200 transition-all duration-200 flex flex-col justify-between"
            >
              <div>
                {/* 5-Star Clinical Rating */}
                <div className="flex items-center gap-1 text-[#0D9488] mb-5" aria-label="5 out of 5 stars">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-[#0D9488] text-[#0D9488]" />
                  ))}
                </div>

                {/* Patient Quote */}
                <blockquote className="text-base sm:text-lg font-medium text-[#062925] leading-relaxed mb-7">
                  “{item.quote}”
                </blockquote>
              </div>

              {/* Patient Attribution with Elegant Monogram Initials */}
              <div className="pt-5 border-t border-teal-100/80 flex items-center gap-3.5">
                <div
                  aria-hidden="true"
                  className="w-11 h-11 rounded-full bg-gradient-to-br from-[#115E59] to-[#0D9488] text-white font-semibold text-sm flex items-center justify-center shrink-0 shadow-[0_4px_12px_rgba(15,118,110,0.3)]"
                >
                  {item.initials}
                </div>
                <div className="min-w-0">
                  <div className="text-sm font-bold text-[#062925] truncate">
                    {item.name}
                  </div>
                  <div className="text-xs text-slate-500 truncate">
                    {item.role} · {item.procedure}
                  </div>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};
