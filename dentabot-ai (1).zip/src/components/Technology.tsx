import React, { useState } from 'react';
import { Check, Activity, ShieldAlert, Sparkles } from 'lucide-react';

interface TechnologyProps {
  onBookScan: () => void;
}

interface ToothRegion {
  id: string;
  code: string;
  name: string;
  status: 'Healthy' | 'Attention';
  confidence: string;
  enamelThickness: string;
  boneDensity: string;
  finding: string;
  recommendation: string;
  cx: number;
  cy: number;
}

const TOOTH_REGIONS: ToothRegion[] = [
  {
    id: 'molar-14',
    code: 'UL-14',
    name: 'Upper Left First Molar (#14)',
    status: 'Healthy',
    confidence: '99.1%',
    enamelThickness: '2.42 mm',
    boneDensity: '98.4% Optimal',
    finding: 'Intact occlusal enamel layer with uniform mineralization and healthy periodontal ligament space.',
    recommendation: 'Continue standard ultrasonic prophylaxis at 6-month intervals.',
    cx: 138,
    cy: 112,
  },
  {
    id: 'premolar-12',
    code: 'UL-12',
    name: 'Upper Left First Premolar (#12)',
    status: 'Attention',
    confidence: '98.7%',
    enamelThickness: '1.68 mm',
    boneDensity: '95.2% Normal',
    finding: 'Early-stage interproximal enamel demineralization detected 0.4mm below outer surface prior to cavity formation.',
    recommendation: 'Non-invasive peptide remineralization therapy recommended; zero drilling required.',
    cx: 235,
    cy: 135,
  },
  {
    id: 'incisor-08',
    code: 'UR-08',
    name: 'Upper Right Central Incisor (#8)',
    status: 'Healthy',
    confidence: '99.3%',
    enamelThickness: '2.15 mm',
    boneDensity: '99.0% Optimal',
    finding: 'Symmetrical incisal edge alignment, zero micro-fractures, and healthy pulpal vascularity.',
    recommendation: 'Eligible for Digital Smile Design optical shade harmony preview.',
    cx: 186,
    cy: 205,
  },
];

const AI_FEATURES = [
  {
    title: 'AI-powered dental analysis',
    detail: 'Deep neural diagnostics evaluate 1,200+ structural checkpoints per tooth in real time.',
  },
  {
    title: 'Early issue detection',
    detail: 'Identifies sub-surface micro-caries and enamel wear months before conventional X-rays.',
  },
  {
    title: 'Personalized treatment planning',
    detail: 'Simulates restorative and orthodontic pathways tailored to your exact craniofacial geometry.',
  },
  {
    title: 'Digital dental imaging',
    detail: 'Radiation-free optical coherence tomography paired with sub-millimeter 3D intraoral scans.',
  },
  {
    title: 'Patient-friendly explanations',
    detail: 'Translates complex clinical radiographs into clear, interactive 3D visual walkthroughs.',
  },
  {
    title: 'Smart appointment assistance',
    detail: 'Automated pre-visit triage and follow-up monitoring synced directly with your care team.',
  },
];

export const Technology: React.FC<TechnologyProps> = ({ onBookScan }) => {
  const [selectedToothId, setSelectedToothId] = useState<string>('premolar-12');
  const [scanMode, setScanMode] = useState<'enamel' | 'periodontal' | 'root'>('enamel');

  const activeTooth =
    TOOTH_REGIONS.find((t) => t.id === selectedToothId) || TOOTH_REGIONS[1];

  return (
    <section
      id="technology"
      className="py-20 sm:py-28 relative overflow-hidden bg-gradient-to-b from-[#ECF7F5] via-[#E4F3F0] to-[#F4FAF9]"
    >
      {/* Subtle Glowing Deep Teal Background Orb */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-1/2 right-0 -translate-y-1/2 w-[36rem] h-[36rem] rounded-full bg-teal-600/15 blur-[130px]"
      />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
          {/* Left Column: Narrative & 6 Core AI Features */}
          <div className="lg:col-span-6">
            <p className="text-xs font-semibold tracking-wider text-[#0F766E] mb-3">
              Clinical Intelligence · Precision Diagnostics
            </p>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#062925] leading-[1.12] mb-5">
              Where Human Care Meets Artificial Intelligence.
            </h2>
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed mb-8">
              TeethCare combines compassionate, experienced dental specialists with real-time artificial intelligence. Our system augments every clinical exam with micron-level optical imaging so nothing is overlooked and treatments remain minimally invasive.
            </p>

            {/* 6 Required Features Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
              {AI_FEATURES.map((feature, index) => (
                <div
                  key={index}
                  className="rounded-xl bg-white/80 backdrop-blur-md border border-teal-100/90 p-4 shadow-[0_6px_20px_-8px_rgba(15,118,110,0.08)] hover:border-teal-400 transition-colors"
                >
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 rounded-full bg-teal-600/15 border border-teal-600/30 flex items-center justify-center text-[#0F766E] shrink-0 mt-0.5">
                      <Check className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <h3 className="text-sm font-bold text-[#062925] mb-1">
                        {feature.title}
                      </h3>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        {feature.detail}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onBookScan}
                className="px-6 py-3.5 text-sm font-semibold text-white bg-gradient-to-r from-[#115E59] to-[#0D9488] hover:from-[#0F766E] hover:to-[#14B8A6] rounded-full shadow-[0_8px_25px_-4px_rgba(15,118,110,0.5)] transition-all duration-150 whitespace-nowrap cursor-pointer"
              >
                Schedule Your AI Dental Scan
              </button>
              <span className="text-xs text-slate-500">
                Click any tooth target on the diagnostic interface to inspect live telemetry
              </span>
            </div>
          </div>

          {/* Right Column: Futuristic Medical AI Dental Diagnostic Visualization in Deep Teal */}
          <div className="lg:col-span-6">
            <div className="relative rounded-3xl bg-[#042421] text-white border border-teal-400/35 shadow-[0_28px_70px_-15px_rgba(15,118,110,0.35)] p-5 sm:p-7 overflow-hidden">
              {/* Subtle Medical Grid Background */}
              <div
                aria-hidden="true"
                className="absolute inset-0 opacity-15 pointer-events-none"
                style={{
                  backgroundImage:
                    'radial-gradient(circle at 1px 1px, rgba(45, 212, 191, 0.5) 1px, transparent 0)',
                  backgroundSize: '24px 24px',
                }}
              />

              {/* Top Medical HUD Header */}
              <div className="relative z-10 flex flex-wrap items-center justify-between gap-3 pb-4 mb-5 border-b border-teal-500/25">
                <div className="flex items-center gap-2.5">
                  <span className="w-2.5 h-2.5 rounded-full bg-teal-400 shadow-[0_0_10px_#2dd4bf] animate-pulse" />
                  <span className="text-xs font-mono font-semibold tracking-wider text-teal-300">
                    AI ANALYSIS
                  </span>
                  <span aria-hidden="true" className="text-teal-700">·</span>
                  <span className="text-xs font-mono text-teal-100/80">
                    3D OPTICAL TOMOGRAPHY
                  </span>
                </div>

                <div className="flex items-center gap-2 bg-teal-500/15 border border-teal-400/40 rounded-lg px-3 py-1">
                  <Activity className="w-3.5 h-3.5 text-teal-300" />
                  <span className="text-xs font-mono font-semibold text-teal-200 tabular-nums">
                    98.7% CONFIDENCE
                  </span>
                </div>
              </div>

              {/* Layer Mode Selector Controls */}
              <div className="relative z-10 flex items-center justify-between gap-2 mb-5">
                <div className="flex items-center gap-1.5 p-1 rounded-xl bg-[#031B18]/90 border border-teal-500/25">
                  {(
                    [
                      { id: 'enamel', label: 'Enamel Density' },
                      { id: 'periodontal', label: 'Periodontal Mesh' },
                      { id: 'root', label: 'Root Geometry' },
                    ] as const
                  ).map((tab) => (
                    <button
                      key={tab.id}
                      type="button"
                      onClick={() => setScanMode(tab.id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap cursor-pointer ${
                        scanMode === tab.id
                          ? 'bg-gradient-to-r from-[#115E59] to-[#0D9488] text-white shadow-sm'
                          : 'text-teal-200/60 hover:text-teal-200'
                      }`}
                    >
                      {tab.label}
                    </button>
                  ))}
                </div>

                <div className="hidden sm:flex items-center gap-3 text-xs font-mono">
                  <span className="flex items-center gap-1.5 text-emerald-300">
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                    Healthy
                  </span>
                  <span className="flex items-center gap-1.5 text-amber-300">
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    Attention
                  </span>
                </div>
              </div>

              {/* Center Interactive Digital Tooth Model & Scanning Interface */}
              <div className="relative z-10 grid grid-cols-1 sm:grid-cols-12 gap-5 items-center bg-[#06312C]/90 border border-teal-500/25 rounded-2xl p-4 sm:p-5 mb-5 overflow-hidden">
                {/* Animated Glowing Deep Teal Scanning Beam */}
                <div
                  aria-hidden="true"
                  className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-teal-400/25 via-teal-400/5 to-transparent border-t border-teal-300/75 animate-scan pointer-events-none"
                />

                {/* SVG High-Precision Anatomical Tooth Model */}
                <div className="sm:col-span-7 relative flex items-center justify-center">
                  <svg
                    viewBox="0 0 360 310"
                    className="w-full max-w-[290px] h-auto drop-shadow-[0_0_25px_rgba(20,184,166,0.3)]"
                    role="img"
                    aria-label="Interactive 3D AI Dental Tooth Diagnostic Model"
                  >
                    <defs>
                      <linearGradient id="tooth-enamel-grad" x1="80" y1="30" x2="280" y2="280" gradientUnits="userSpaceOnUse">
                        <stop offset="0%" stopColor="#CCFBF1" stopOpacity="0.92" />
                        <stop offset="45%" stopColor="#5EEAD4" stopOpacity="0.65" />
                        <stop offset="100%" stopColor="#0F766E" stopOpacity="0.4" />
                      </linearGradient>
                      <linearGradient id="tooth-pulp-grad" x1="140" y1="100" x2="220" y2="260" gradientUnits="userSpaceOnUse">
                        <stop offset="0%" stopColor="#2DD4BF" stopOpacity="0.55" />
                        <stop offset="100%" stopColor="#115E59" stopOpacity="0.25" />
                      </linearGradient>
                      <radialGradient id="attention-hotspot" cx="50%" cy="50%" r="50%">
                        <stop offset="0%" stopColor="#F59E0B" stopOpacity="0.9" />
                        <stop offset="100%" stopColor="#F59E0B" stopOpacity="0" />
                      </radialGradient>
                    </defs>

                    {/* Outer Diagnostic Reticle Rings */}
                    <circle
                      cx="180"
                      cy="155"
                      r="132"
                      fill="none"
                      stroke="#14B8A6"
                      strokeOpacity="0.25"
                      strokeWidth="1"
                      strokeDasharray="4 6"
                    />
                    <circle
                      cx="180"
                      cy="155"
                      r="108"
                      fill="none"
                      stroke="#2DD4BF"
                      strokeOpacity="0.2"
                      strokeWidth="1"
                    />

                    {/* Crosshair Axis Ticks */}
                    <line x1="25" y1="155" x2="58" y2="155" stroke="#2DD4BF" strokeOpacity="0.35" strokeWidth="1" />
                    <line x1="302" y1="155" x2="335" y2="155" stroke="#2DD4BF" strokeOpacity="0.35" strokeWidth="1" />
                    <line x1="180" y1="12" x2="180" y2="35" stroke="#2DD4BF" strokeOpacity="0.35" strokeWidth="1" />
                    <line x1="180" y1="275" x2="180" y2="298" stroke="#2DD4BF" strokeOpacity="0.35" strokeWidth="1" />

                    {/* Alveolar Bone / Periodontal Mesh Contour */}
                    {scanMode !== 'enamel' && (
                      <path
                        d="M95 165 C115 182, 145 186, 180 182 C215 186, 245 182, 265 165 L252 275 C225 288, 135 288, 108 275 Z"
                        fill="#0F766E"
                        fillOpacity="0.18"
                        stroke="#2DD4BF"
                        strokeWidth="1.2"
                        strokeDasharray="3 3"
                      />
                    )}

                    {/* Outer Tooth Crown & Dual Root Anatomical Silhouette */}
                    <path
                      d="M128 56 C102 56, 86 78, 86 108 C86 142, 104 168, 114 206 C121 232, 127 268, 141 268 C153 268, 159 236, 168 206 C172 192, 176 186, 180 186 C184 186, 188 192, 192 206 C201 236, 207 268, 219 268 C233 268, 239 232, 246 206 C256 168, 274 142, 274 108 C274 78, 258 56, 232 56 C212 56, 196 68, 180 68 C164 68, 148 56, 128 56 Z"
                      fill="url(#tooth-enamel-grad)"
                      stroke="#2DD4BF"
                      strokeWidth="2.2"
                    />

                    {/* Topographical Wireframe Mesh Lines on Tooth */}
                    <path
                      d="M92 108 Q180 128 268 108"
                      fill="none"
                      stroke="#99F6E4"
                      strokeOpacity="0.55"
                      strokeWidth="1"
                    />
                    <path
                      d="M98 138 Q180 158 262 138"
                      fill="none"
                      stroke="#99F6E4"
                      strokeOpacity="0.45"
                      strokeWidth="1"
                    />
                    <path
                      d="M142 62 C152 130, 148 200, 141 264"
                      fill="none"
                      stroke="#99F6E4"
                      strokeOpacity="0.35"
                      strokeWidth="1"
                    />
                    <path
                      d="M218 62 C208 130, 212 200, 219 264"
                      fill="none"
                      stroke="#99F6E4"
                      strokeOpacity="0.35"
                      strokeWidth="1"
                    />

                    {/* Inner Dentin & Pulp Chamber Geometry */}
                    <path
                      d="M138 96 C122 96, 114 110, 116 130 C118 152, 130 175, 136 212 C139 228, 141 248, 144 248 C147 248, 152 220, 160 190 C166 172, 174 166, 180 166 C186 166, 194 172, 200 190 C208 220, 213 248, 216 248 C219 248, 221 228, 224 212 C230 175, 242 152, 244 130 C246 110, 238 96, 222 96 C206 96, 194 106, 180 106 C166 106, 154 96, 138 96 Z"
                      fill="url(#tooth-pulp-grad)"
                      stroke="#2DD4BF"
                      strokeWidth={scanMode === 'root' ? '2' : '1.2'}
                      strokeDasharray={scanMode === 'root' ? 'none' : '4 2'}
                    />

                    {/* Attention Zone Pulse Overlay on UL-12 */}
                    <circle cx="235" cy="135" r="26" fill="url(#attention-hotspot)" />

                    {/* Interactive Diagnostic Nodes on Tooth Model */}
                    {TOOTH_REGIONS.map((node) => {
                      const isActive = node.id === selectedToothId;
                      const isAttention = node.status === 'Attention';
                      return (
                        <g
                          key={node.id}
                          onClick={() => setSelectedToothId(node.id)}
                          className="cursor-pointer"
                        >
                          <circle
                            cx={node.cx}
                            cy={node.cy}
                            r={isActive ? 14 : 10}
                            fill={isAttention ? 'rgba(245, 158, 11, 0.22)' : 'rgba(20, 184, 166, 0.25)'}
                            stroke={isAttention ? '#FBBF24' : '#2DD4BF'}
                            strokeWidth={isActive ? '2' : '1.2'}
                          />
                          <circle
                            cx={node.cx}
                            cy={node.cy}
                            r="4.5"
                            fill={isAttention ? '#FBBF24' : '#2DD4BF'}
                          />
                        </g>
                      );
                    })}

                    {/* Technical Coordinate Callout Line */}
                    <line
                      x1={activeTooth.cx}
                      y1={activeTooth.cy}
                      x2="310"
                      y2="52"
                      stroke="#2DD4BF"
                      strokeWidth="1.2"
                      strokeDasharray="3 3"
                    />
                    <rect
                      x="252"
                      y="24"
                      width="96"
                      height="26"
                      rx="6"
                      fill="#042421"
                      stroke="#2DD4BF"
                      strokeWidth="1"
                    />
                    <text
                      x="300"
                      y="41"
                      textAnchor="middle"
                      fill="#5EEAD4"
                      fontSize="11"
                      fontFamily="monospace"
                      fontWeight="600"
                    >
                      {activeTooth.code} · {activeTooth.confidence}
                    </text>
                  </svg>
                </div>

                {/* Right Telemetry Metrics Column inside Diagnostic Viewport */}
                <div className="sm:col-span-5 space-y-3">
                  <div className="rounded-xl bg-[#042421]/90 border border-teal-500/25 p-3.5">
                    <div className="text-[11px] font-mono text-teal-200/70 mb-1">
                      DIAGNOSTIC CONFIDENCE
                    </div>
                    <div className="flex items-baseline justify-between">
                      <span className="text-2xl font-bold font-mono text-teal-300 tabular-nums">
                        {activeTooth.confidence}
                      </span>
                      <span className="text-[11px] font-mono text-emerald-300">
                        VERIFIED
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-[#031B18] rounded-full mt-2 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#0F766E] to-[#2DD4BF] rounded-full"
                        style={{ width: activeTooth.confidence }}
                      />
                    </div>
                  </div>

                  <div className="rounded-xl bg-[#042421]/90 border border-teal-500/25 p-3.5">
                    <div className="text-[11px] font-mono text-teal-200/70 mb-1">
                      ENAMEL LAYER THICKNESS
                    </div>
                    <div className="text-base font-bold font-mono text-white tabular-nums">
                      {activeTooth.enamelThickness}
                    </div>
                    <div className="text-[11px] text-teal-200/70 mt-0.5">
                      Alveolar Support: <span className="text-teal-200 font-mono">{activeTooth.boneDensity}</span>
                    </div>
                  </div>

                  {/* Interactive Tooth Selector Buttons */}
                  <div className="space-y-1.5 pt-1">
                    <div className="text-[11px] font-mono text-teal-200/70">
                      SELECT DIAGNOSTIC NODE:
                    </div>
                    <div className="grid grid-cols-3 gap-1.5">
                      {TOOTH_REGIONS.map((region) => (
                        <button
                          key={region.id}
                          type="button"
                          onClick={() => setSelectedToothId(region.id)}
                          className={`px-2 py-1.5 rounded-lg text-xs font-mono font-semibold border transition-all cursor-pointer ${
                            selectedToothId === region.id
                              ? 'bg-teal-500/25 border-teal-300 text-white'
                              : 'bg-[#031B18]/80 border-teal-800 text-teal-200/60 hover:text-teal-200'
                          }`}
                        >
                          {region.code}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Bottom Live Diagnostic Readout Panel */}
              <div className="relative z-10 rounded-2xl bg-[#06312C]/95 border border-teal-400/30 p-4">
                <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                  <div className="text-sm font-bold text-white">
                    {activeTooth.name}
                  </div>
                  <div
                    className={`inline-flex items-center gap-1.5 text-xs font-mono font-semibold ${
                      activeTooth.status === 'Healthy'
                        ? 'text-teal-300'
                        : 'text-amber-300'
                    }`}
                  >
                    {activeTooth.status === 'Healthy' ? (
                      <Sparkles className="w-3.5 h-3.5" />
                    ) : (
                      <ShieldAlert className="w-3.5 h-3.5" />
                    )}
                    <span>STATUS: {activeTooth.status.toUpperCase()}</span>
                  </div>
                </div>

                <p className="text-xs text-teal-50/85 leading-relaxed mb-2">
                  {activeTooth.finding}
                </p>
                <div className="text-xs text-teal-300 font-medium">
                  AI Treatment Plan: <span className="text-white/90 font-normal">{activeTooth.recommendation}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
