import React, { useState } from 'react';
import { X, Lock, CheckCircle2 } from 'lucide-react';
import { DentalLogoIcon } from './Navbar';

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessLogin: (userName: string) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({
  isOpen,
  onClose,
  onSuccessLogin,
}) => {
  const [email, setEmail] = useState('sarah.mitchell@example.com');
  const [patientId, setPatientId] = useState('TC-90421');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) {
      setError('Please enter a valid patient email address.');
      return;
    }
    if (!patientId.trim()) {
      setError('Please enter your Patient ID or Access Passcode.');
      return;
    }
    const extractedName = email.split('@')[0].replace('.', ' ');
    const formattedName = extractedName
      .split(' ')
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ');
    onSuccessLogin(formattedName || 'Sarah Mitchell');
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="login-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#042421]/60 backdrop-blur-md"
    >
      <div className="relative w-full max-w-md rounded-3xl bg-white border border-teal-100 shadow-[0_25px_70px_rgba(4,36,33,0.3)] p-7 sm:p-8">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close patient portal modal"
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-teal-50 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2.5 mb-5">
          <DentalLogoIcon className="w-8 h-8" />
          <span className="text-lg font-bold text-[#062925]">
            Teeth<span className="text-[#0F766E]">Care</span> Portal
          </span>
        </div>

        <h3 id="login-modal-title" className="text-2xl font-bold text-[#062925] mb-2">
          Patient Diagnostic Portal
        </h3>
        <p className="text-sm text-slate-600 mb-6">
          Access your 3D intraoral scans, Digital Smile Design simulations, and upcoming appointments.
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label htmlFor="portal-email" className="block text-xs font-semibold text-slate-700 mb-1.5">
              Patient Email
            </label>
            <input
              id="portal-email"
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setError('');
              }}
              className="w-full rounded-xl border border-teal-200 bg-teal-50/40 px-4 py-3 text-sm text-[#062925] focus:outline-none focus:border-[#0F766E]"
            />
          </div>

          <div>
            <label htmlFor="portal-pass" className="block text-xs font-semibold text-slate-700 mb-1.5">
              Patient ID / Passcode
            </label>
            <input
              id="portal-pass"
              type="text"
              value={patientId}
              onChange={(e) => {
                setPatientId(e.target.value);
                setError('');
              }}
              className="w-full rounded-xl border border-teal-200 bg-teal-50/40 px-4 py-3 text-sm font-mono text-[#062925] focus:outline-none focus:border-[#0F766E]"
            />
          </div>

          {error && <p className="text-xs text-rose-600">{error}</p>}

          <button
            type="submit"
            className="w-full py-3.5 px-6 text-sm font-semibold text-white bg-gradient-to-r from-[#115E59] to-[#0D9488] hover:from-[#0F766E] hover:to-[#14B8A6] rounded-full shadow-[0_8px_22px_-3px_rgba(15,118,110,0.45)] transition-all cursor-pointer flex items-center justify-center gap-2"
          >
            <Lock className="w-4 h-4" />
            <span>Sign In to Patient Portal</span>
          </button>
        </form>
      </div>
    </div>
  );
};

interface InfoModalProps {
  topic: 'FAQ' | 'Privacy Policy' | 'Terms' | 'Careers' | null;
  onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ topic, onClose }) => {
  if (!topic) return null;

  const contentMap = {
    FAQ: {
      title: 'Frequently Asked Questions',
      subtitle: 'Clinical & AI Technology Overview',
      items: [
        {
          q: 'Is the AI Dental Scan radiation-free?',
          a: 'Yes. Our primary 3D optical intraoral scanner uses near-infrared transillumination and structured light—zero ionizing radiation—to map surface and sub-surface enamel structures.',
        },
        {
          q: 'Does a robot perform the treatment on its own?',
          a: 'Never. Every diagnostic scan, treatment plan, and clinical procedure is directly led and verified by our 15+ board-certified dental specialists, augmented by AI precision guidance.',
        },
        {
          q: 'How accurate is TeethCare Smart Diagnosis?',
          a: 'Our diagnostic system achieves 98.7% clinical concordance in identifying early enamel demineralization, occlusal wear, and periodontal changes.',
        },
      ],
    },
    'Privacy Policy': {
      title: 'Clinical Privacy & Data Protection',
      subtitle: 'HIPAA & GDPR Encrypted Medical Architecture',
      items: [
        {
          q: 'End-to-End 3D Scan Encryption',
          a: 'All intraoral point clouds, radiographs, and Digital Smile Design simulations are encrypted with AES-256 at rest and in transit.',
        },
        {
          q: 'Patient Ownership of Diagnostic Data',
          a: 'You retain full access and ownership of your 3D dental models and can export them at any time via your TeethCare Patient Portal.',
        },
      ],
    },
    Terms: {
      title: 'Terms of Clinical Service',
      subtitle: 'TeethCare Medical Group Standards',
      items: [
        {
          q: 'Clinical Consultation & Triage',
          a: 'Online AI consultations provide preliminary educational and scheduling guidance. Final clinical diagnosis is always confirmed in person by your attending TeethCare dentist.',
        },
        {
          q: 'Appointment Scheduling & Zero-Wait Guarantee',
          a: 'We ask for 24 hours notice for rescheduling so we can calibrate our robotic optical suites for incoming patients.',
        },
      ],
    },
    Careers: {
      title: 'Careers at TeethCare',
      subtitle: 'Join Our Clinical & Medical Robotics Team',
      items: [
        {
          q: 'Senior Prosthodontist & Digital Smile Specialist (San Francisco / Zurich)',
          a: 'Lead cosmetic and restorative cases using our real-time 3D craniofacial simulation suite.',
        },
        {
          q: 'Computer Vision Engineer — Optical Tomography',
          a: 'Advance our sub-millimeter enamel segmentation models alongside clinical researchers.',
        },
      ],
    },
  }[topic];

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#042421]/60 backdrop-blur-md"
    >
      <div className="relative w-full max-w-lg rounded-3xl bg-white border border-teal-100 shadow-[0_25px_70px_rgba(4,36,33,0.3)] p-7 sm:p-8 max-h-[85vh] overflow-y-auto">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close modal"
          className="absolute top-5 right-5 p-2 rounded-full text-slate-400 hover:text-slate-700 hover:bg-teal-50 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-xs font-semibold text-[#0F766E] mb-1">
          {contentMap.subtitle}
        </div>
        <h3 className="text-2xl font-bold text-[#062925] mb-5">
          {contentMap.title}
        </h3>

        <div className="space-y-4 mb-6">
          {contentMap.items.map((item, idx) => (
            <div key={idx} className="rounded-2xl bg-teal-50/50 border border-teal-100 p-4">
              <div className="flex items-start gap-2.5">
                <CheckCircle2 className="w-4 h-4 text-[#0D9488] shrink-0 mt-0.5" />
                <div>
                  <h4 className="text-sm font-bold text-[#062925] mb-1">
                    {item.q}
                  </h4>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {item.a}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="px-6 py-2.5 text-sm font-semibold text-white bg-gradient-to-r from-[#115E59] to-[#0D9488] rounded-full cursor-pointer"
        >
          Close Window
        </button>
      </div>
    </div>
  );
};
