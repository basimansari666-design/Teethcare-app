import React, { useState } from 'react';
import { ArrowRight, CheckCircle2 } from 'lucide-react';

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  description: string;
  duration: string;
  precisionMetric: string;
  clinicalHighlights: string[];
  icon: React.ReactNode;
}

interface ServicesProps {
  onSelectServiceForBooking: (serviceTitle: string) => void;
}

const ScanSvgIcon = () => (
  <svg viewBox="0 0 32 32" fill="none" className="w-6 h-6" aria-hidden="true">
    <path
      d="M6 10V8C6 6.89543 6.89543 6 8 6H10M22 6H24C25.1046 6 26 6.89543 26 8V10M26 22V24C26 25.1046 25.1046 26 24 26H22M10 26H8C6.89543 26 6 25.1046 6 24V22"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    />
    <path
      d="M12.2 11C10.7 11 9.6 12.2 9.6 13.9C9.6 16 10.5 17.8 11.2 20C11.6 21.3 12.1 22.5 13 22.5C13.8 22.5 14.2 21.1 14.7 19.7C15 19 15.5 18.7 16 18.7C16.5 18.7 17 19 17.3 19.7C17.8 21.1 18.2 22.5 19 22.5C19.9 22.5 20.4 21.3 20.8 20C21.5 17.8 22.4 16 22.4 13.9C22.4 12.2 21.3 11 19.8 11C18.6 11 17.6 11.6 16.6 11.9C16.2 12 15.8 12 15.4 11.9C14.4 11.6 13.4 11 12.2 11Z"
      stroke="currentColor"
      strokeWidth="1.8"
    />
    <path d="M8 16H24" stroke="#14B8A6" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

const DiagnosisSvgIcon = () => (
  <svg viewBox="0 0 32 32" fill="none" className="w-6 h-6" aria-hidden="true">
    <circle cx="16" cy="16" r="10" stroke="currentColor" strokeWidth="1.8" />
    <path
      d="M10.5 16.5L13.5 16.5L15.2 12.5L17.2 19.5L18.8 16.5H21.5"
      stroke="#14B8A6"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <circle cx="16" cy="6" r="1.5" fill="currentColor" />
    <circle cx="16" cy="26" r="1.5" fill="currentColor" />
    <circle cx="6" cy="16" r="1.5" fill="currentColor" />
    <circle cx="26" cy="16" r="1.5" fill="currentColor" />
  </svg>
);

const SmileDesignSvgIcon = () => (
  <svg viewBox="0 0 32 32" fill="none" className="w-6 h-6" aria-hidden="true">
    <path
      d="M6.5 15.5C8.5 20.5 12 22.5 16 22.5C20 22.5 23.5 20.5 25.5 15.5"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
    />
    <path
      d="M7.5 14C10.5 15.5 13.2 16 16 16C18.8 16 21.5 15.5 24.5 14"
      stroke="#14B8A6"
      strokeWidth="1.8"
      strokeLinecap="round"
    />
    <path d="M12.5 16.2V21.5M16 16.3V22.2M19.5 16.2V21.5" stroke="currentColor" strokeWidth="1.5" />
    <rect x="4" y="7" width="24" height="19" rx="5" stroke="currentColor" strokeWidth="1.6" strokeDasharray="3 3" />
  </svg>
);

const ConsultationSvgIcon = () => (
  <svg viewBox="0 0 32 32" fill="none" className="w-6 h-6" aria-hidden="true">
    <path
      d="M7 10C7 7.79086 8.79086 6 11 6H21C23.2091 6 25 7.79086 25 10V18C25 20.2091 23.2091 22 21 22H14.5L9.5 25.5V22H11C8.79086 22 7 20.2091 7 18V10Z"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinejoin="round"
    />
    <path d="M12 12.5H20M12 16.5H17" stroke="#14B8A6" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'ai-dental-scan',
    number: '01',
    title: 'AI Dental Scan',
    description:
      'Advanced AI-assisted dental scanning helps detect potential issues early.',
    duration: '12 Minutes',
    precisionMetric: '18-Micron Optical Resolution',
    clinicalHighlights: [
      'Zero-radiation near-infrared enamel transillumination',
      'Full-arch 3D point cloud generated in 45 seconds',
      'Sub-surface micro-fissure and early demineralization mapping',
    ],
    icon: <ScanSvgIcon />,
  },
  {
    id: 'smart-diagnosis',
    number: '02',
    title: 'Smart Diagnosis',
    description:
      'Intelligent analysis helps dentists understand dental conditions and plan treatment.',
    duration: '15 Minutes',
    precisionMetric: '98.7% Clinical Concordance',
    clinicalHighlights: [
      'Cross-referenced against 4.2M verified clinical dental scans',
      'Side-by-side specialist verification with transparent visual overlays',
      'Predictive periodontal bone-support and bite-force modeling',
    ],
    icon: <DiagnosisSvgIcon />,
  },
  {
    id: 'digital-smile-design',
    number: '03',
    title: 'Digital Smile Design',
    description:
      'Visualize personalized cosmetic dental treatment before starting.',
    duration: '25 Minutes',
    precisionMetric: '1:1 Craniofacial Harmonics',
    clinicalHighlights: [
      'Photorealistic 3D smile simulation synced to facial motion',
      'Custom porcelain shade and tooth proportion calibration',
      'Instant preview of aligner or veneer outcomes before treatment',
    ],
    icon: <SmileDesignSvgIcon />,
  },
  {
    id: 'ai-dental-consultation',
    number: '04',
    title: 'AI Dental Consultation',
    description:
      'Get quick AI-assisted guidance and prepare for your dental appointment.',
    duration: '20 Minutes',
    precisionMetric: '24/7 Pre-Visit Triage',
    clinicalHighlights: [
      'Interactive plain-language breakdown of every diagnostic finding',
      'Transparent cost, timeline, and comfort-level comparison',
      'Seamless handoff to your dedicated TeethCare dental specialist',
    ],
    icon: <ConsultationSvgIcon />,
  },
];

export const Services: React.FC<ServicesProps> = ({
  onSelectServiceForBooking,
}) => {
  const [selectedServiceId, setSelectedServiceId] = useState<string>('ai-dental-scan');
  const [previewImgError, setPreviewImgError] = useState(false);

  const activeService =
    SERVICES_DATA.find((s) => s.id === selectedServiceId) || SERVICES_DATA[0];

  return (
    <section
      id="services"
      className="py-20 sm:py-28 relative bg-gradient-to-b from-[#F4FAF9] via-white to-[#ECF7F5]"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl mx-auto text-center mb-14 sm:mb-16">
          <p className="text-xs font-semibold tracking-wider text-[#0F766E] mb-3">
            Clinical Capabilities · Intelligent Dentistry
          </p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#062925] mb-5">
            Advanced Care, Simplified.
          </h2>
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Combining experienced dental professionals with intelligent technology for a faster, safer and more comfortable dental experience.
          </p>
        </div>

        {/* 4 Premium Service Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {SERVICES_DATA.map((service) => {
            const isSelected = service.id === selectedServiceId;
            return (
              <div
                key={service.id}
                onClick={() => setSelectedServiceId(service.id)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setSelectedServiceId(service.id);
                  }
                }}
                className={`group relative rounded-2xl p-6 sm:p-7 transition-all duration-200 flex flex-col justify-between cursor-pointer text-left ${
                  isSelected
                    ? 'bg-white border-2 border-[#0F766E] shadow-[0_20px_45px_-12px_rgba(15,118,110,0.22)] -translate-y-1'
                    : 'bg-white/80 backdrop-blur-md border border-teal-100 hover:border-teal-300/90 shadow-[0_10px_30px_-10px_rgba(15,118,110,0.08)] hover:shadow-[0_18px_40px_-12px_rgba(15,118,110,0.16)] hover:-translate-y-1'
                }`}
              >
                <div>
                  {/* Top Row: Clean Editorial Number + Icon */}
                  <div className="flex items-center justify-between gap-3 mb-6">
                    <div
                      className={`w-12 h-12 rounded-xl flex items-center justify-center transition-colors duration-200 ${
                        isSelected
                          ? 'bg-gradient-to-br from-[#115E59] to-[#0D9488] text-white shadow-[0_6px_18px_rgba(15,118,110,0.35)]'
                          : 'bg-teal-50 text-[#0F766E] group-hover:bg-teal-100/80'
                      }`}
                    >
                      {service.icon}
                    </div>
                    <span className="text-xs font-mono font-semibold text-slate-400 tabular-nums">
                      {service.number}
                    </span>
                  </div>

                  {/* Card Title & Description */}
                  <h3 className="text-xl font-bold text-[#062925] mb-2.5 group-hover:text-[#0F766E] transition-colors">
                    {service.title}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-6">
                    {service.description}
                  </p>
                </div>

                {/* Unboxed Metadata Footer + Action */}
                <div className="pt-4 border-t border-teal-100/80 flex items-center justify-between text-xs text-slate-500">
                  <span className="tabular-nums font-medium">{service.duration}</span>
                  <span className="inline-flex items-center gap-1 font-semibold text-[#0F766E] group-hover:text-[#115E59] transition-colors">
                    <span>Inspect Protocol</span>
                    <ArrowRight className="w-3.5 h-3.5 transition-transform duration-150 group-hover:translate-x-0.5" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Interactive Clinical Protocol Spotlight for Selected Service */}
        <div className="rounded-2xl bg-white/90 backdrop-blur-xl border border-teal-100/90 shadow-[0_16px_50px_-15px_rgba(15,118,110,0.12)] p-6 sm:p-8 lg:p-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7">
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 mb-2">
                <span className="font-semibold text-[#0F766E]">
                  {activeService.number}. Clinical Protocol Specification
                </span>
                <span aria-hidden="true">·</span>
                <span className="font-mono tabular-nums">{activeService.precisionMetric}</span>
                <span aria-hidden="true">·</span>
                <span className="tabular-nums">Est. Session: {activeService.duration}</span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-bold text-[#062925] mb-3">
                {activeService.title}
              </h3>
              <p className="text-sm sm:text-base text-slate-600 leading-relaxed mb-6">
                {activeService.description} Every stage is guided by real-time optical telemetry and reviewed by a board-certified TeethCare dental specialist.
              </p>

              <ul className="space-y-3 mb-7">
                {activeService.clinicalHighlights.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-3 text-sm text-slate-700">
                    <CheckCircle2 className="w-4 h-4 text-[#0D9488] shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>

              <div className="flex flex-wrap items-center gap-4">
                <button
                  type="button"
                  onClick={() => onSelectServiceForBooking(activeService.title)}
                  className="px-6 py-3 text-sm font-semibold text-white bg-gradient-to-r from-[#115E59] to-[#0D9488] hover:from-[#0F766E] hover:to-[#14B8A6] rounded-full shadow-[0_8px_22px_-4px_rgba(15,118,110,0.45)] transition-all duration-150 whitespace-nowrap cursor-pointer"
                >
                  Book {activeService.title}
                </button>
                <span className="text-xs text-slate-500">
                  Includes complimentary 3D digital baseline report
                </span>
              </div>
            </div>

            <div className="lg:col-span-5">
              <div className="relative rounded-xl overflow-hidden border border-teal-100 bg-[#042F2E] aspect-[4/3]">
                {!previewImgError ? (
                  <img
                    src="/src/assets/images/smile_design_preview_1791213116813.jpg"
                    alt="Frameless glass medical display showing 3D digital tooth and dental arch scan"
                    referrerPolicy="no-referrer"
                    onError={() => setPreviewImgError(true)}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-6 bg-gradient-to-br from-[#062925] to-[#042F2E] text-white">
                    <SmileDesignSvgIcon />
                    <span className="text-xs font-mono mt-2 text-teal-300">
                      3D Optical Dental Arch Visualization
                    </span>
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-[#042F2E]/75 via-[#0F766E]/10 to-transparent flex items-end p-4">
                  <div className="w-full flex items-center justify-between text-xs text-white/95">
                    <span className="font-medium">{activeService.title} Interface</span>
                    <span className="font-mono text-teal-300 tabular-nums">
                      {activeService.precisionMetric}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
