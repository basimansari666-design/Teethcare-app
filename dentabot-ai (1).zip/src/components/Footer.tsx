import React from 'react';
import { DentalLogoIcon } from './Navbar';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
  onSelectService: (serviceName: string) => void;
  onOpenInfoModal: (topic: 'FAQ' | 'Privacy Policy' | 'Terms' | 'Careers') => void;
}

export const Footer: React.FC<FooterProps> = ({
  onNavigate,
  onSelectService,
  onOpenInfoModal,
}) => {
  return (
    <footer className="bg-white border-t border-teal-100/90 pt-16 pb-12 text-slate-600">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-10 pb-12 border-b border-teal-100/80">
          {/* Brand Column */}
          <div className="lg:col-span-5">
            <a
              href="#top"
              onClick={(e) => {
                e.preventDefault();
                onNavigate('top');
              }}
              className="inline-flex items-center gap-2.5 text-xl font-bold tracking-tight mb-4 focus:outline-none"
            >
              <DentalLogoIcon className="w-8 h-8" />
              <span className="text-[#062925]">
                Teeth<span className="text-[#0F766E]">Care</span>
              </span>
            </a>
            <p className="text-sm text-slate-500 leading-relaxed max-w-sm mb-6">
              Friendly, Precise, Painless Dentistry Powered by AI. Combining experienced dental specialists with optical robotics for a transparent healthcare experience.
            </p>
            <div className="text-xs text-slate-400">
              San Francisco · Zurich · Tokyo
            </div>
          </div>

          {/* Services Column */}
          <div className="lg:col-span-2">
            <h3 className="text-sm font-bold text-[#062925] mb-4">Services</h3>
            <ul className="space-y-2.5 text-sm">
              {[
                { label: 'AI Dental Scan', service: 'AI Dental Scan' },
                { label: 'Smart Diagnosis', service: 'Smart Diagnosis' },
                { label: 'Smile Design', service: 'Digital Smile Design' },
                { label: 'AI Consultation', service: 'AI Dental Consultation' },
              ].map((item) => (
                <li key={item.label}>
                  <button
                    type="button"
                    onClick={() => onSelectService(item.service)}
                    className="text-slate-600 hover:text-[#0F766E] transition-colors cursor-pointer text-left"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Column */}
          <div className="lg:col-span-2">
            <h3 className="text-sm font-bold text-[#062925] mb-4">Company</h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <a
                  href="#about"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('about');
                  }}
                  className="text-slate-600 hover:text-[#0F766E] transition-colors"
                >
                  About Us
                </a>
              </li>
              <li>
                <a
                  href="#technology"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('technology');
                  }}
                  className="text-slate-600 hover:text-[#0F766E] transition-colors"
                >
                  Technology
                </a>
              </li>
              <li>
                <a
                  href="#contact"
                  onClick={(e) => {
                    e.preventDefault();
                    onNavigate('appointment');
                  }}
                  className="text-slate-600 hover:text-[#0F766E] transition-colors"
                >
                  Contact
                </a>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('Careers')}
                  className="text-slate-600 hover:text-[#0F766E] transition-colors cursor-pointer text-left"
                >
                  Careers
                </button>
              </li>
            </ul>
          </div>

          {/* Support Column */}
          <div className="lg:col-span-3">
            <h3 className="text-sm font-bold text-[#062925] mb-4">Support</h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('FAQ')}
                  className="text-slate-600 hover:text-[#0F766E] transition-colors cursor-pointer text-left"
                >
                  FAQ
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('Privacy Policy')}
                  className="text-slate-600 hover:text-[#0F766E] transition-colors cursor-pointer text-left"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => onOpenInfoModal('Terms')}
                  className="text-slate-600 hover:text-[#0F766E] transition-colors cursor-pointer text-left"
                >
                  Terms
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Copyright Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p>© 2026 TeethCare. All rights reserved.</p>
          <div className="flex items-center gap-4">
            <span>HIPAA & GDPR Compliant Clinical Platform</span>
            <span aria-hidden="true">·</span>
            <span>98.7% Diagnostic Concordance</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
