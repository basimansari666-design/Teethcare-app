import React, { useState } from 'react';

interface HowItWorksProps {
  onStartBooking: () => void;
}

const StepCalendarSvg = () => (
  <svg viewBox="0 0 32 32" fill="none" className="w-6 h-6" aria-hidden="true">
    <rect x="5" y="7" width="22" height="20" rx="4" stroke="currentColor" strokeWidth="1.8" />
    <path d="M5 12.5H27" stroke="currentColor" strokeWidth="1.8" />
    <path d="M10.5 4.5V8M21.5 4.5V8" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    <circle cx="12" cy="17.5" r="1.5" fill="#14B8A6" />
    <circle cx="16" cy="17.5" r="1.5" fill="currentColor" />
    <circle cx="20" cy="17.5" r="1.5" fill="currentColor" />
    <path d="M11 22H21" stroke="#14B8A6" strokeWidth="1.8" strokeLinecap="round" />
  </svg>
);

const StepAssessmentSvg = () => (
  <svg viewBox="0 0 32 32" fill="none" className="w-6 h-6" aria-hidden="true">
    <path
      d="M16 4L26 9.5V22.5L16 28L6 22.5V9.5L16 4Z"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinejoin="round"
    />
    <circle cx="16" cy="16" r="4.5" stroke="#14B8A6" strokeWidth="2" />
    <path d="M16 7V11.5M16 20.5V25M8.5 16H11.5M20.5 16H23.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
  </svg>
);

const StepTreatmentSvg = () => (
  <svg viewBox="0 0 32 32" fill="none" className="w-6 h-6" aria-hidden="true">
    <path
      d="M16 5C11 5 7 8.5 7 13.8C7 20.4 16 27 16 27C16 27 25 20.4 25 13.8C25 8.5 21 5 16 5Z"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinejoin="round"
    />
    <path
      d="M12.5 14.5L15 17L20 12"
      stroke="#14B8A6"
      strokeWidth="2.2"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const STEPS = [
  {
    number: '01',
    title: 'Book Your Appointment',
    subtitle: 'Instant Digital Scheduling',
    description:
      'Choose your preferred dental service, date, and time online in under 60 seconds with immediate confirmation.',
    timeNote: 'Under 1 Minute Online',
    icon: <StepCalendarSvg />,
  },
  {
    number: '02',
    title: 'AI-Assisted Dental Assessment',
    subtitle: '3D Optical Intraoral Mapping',
    description:
      'Experience a comfortable, radiation-free 3D optical scan that maps every tooth with 98.7% diagnostic confidence.',
    timeNote: '12-Minute Painless Scan',
    icon: <StepAssessmentSvg />,
  },
  {
    number: '03',
    title: 'Personalized Treatment',
    subtitle: 'Specialist-Guided Care',
    description:
      'Review your transparent 3D smile simulation with your dentist and receive gentle, precision-calibrated care.',
    timeNote: 'Tailored to Your Smile',
    icon: <StepTreatmentSvg />,
  },
];

export const HowItWorks: React.FC<HowItWorksProps> = ({ onStartBooking }) => {
  const [activeStepIndex, setActiveStepIndex] = useState<number>(1);

  return (
    <section className="py-20 sm:py-28 relative bg-gradient-to-b from-[#EFF9F7] to-[#F4FAF9]">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="max-w-2xl mx-auto text-center mb-16">
          <p className="text-xs font-semibold tracking-wider text-[#0F766E] mb-3">
            Streamlined Clinical Pathway
          </p>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#062925] mb-4">
            How TeethCare Works
          </h2>
          <p className="text-base sm:text-lg text-slate-600 leading-relaxed">
            Three seamless steps from booking your visit to experiencing precision, stress-free dental care.
          </p>
        </div>

        {/* 3-Step Grid with Connecting Lines */}
        <div className="relative grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Desktop Horizontal Connecting Line */}
          <div
            aria-hidden="true"
            className="hidden md:block absolute top-14 left-[16%] right-[16%] h-[2px] bg-gradient-to-r from-teal-200 via-[#0D9488] to-teal-200 z-0"
          />

          {STEPS.map((step, idx) => {
            const isActive = activeStepIndex === idx;
            return (
              <div
                key={step.number}
                onClick={() => setActiveStepIndex(idx)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    setActiveStepIndex(idx);
                  }
                }}
                className={`relative z-10 rounded-2xl p-7 transition-all duration-200 cursor-pointer text-left flex flex-col justify-between ${
                  isActive
                    ? 'bg-white border-2 border-[#0F766E] shadow-[0_20px_45px_-12px_rgba(15,118,110,0.2)] -translate-y-1'
                    : 'bg-white/80 backdrop-blur-md border border-teal-100 hover:border-teal-300 shadow-[0_10px_30px_-10px_rgba(15,118,110,0.08)] hover:-translate-y-0.5'
                }`}
              >
                <div>
                  {/* Number Badge & SVG Icon */}
                  <div className="flex items-center justify-between mb-6">
                    <div
                      className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-colors ${
                        isActive
                          ? 'bg-gradient-to-br from-[#115E59] to-[#0D9488] text-white shadow-[0_8px_20px_rgba(15,118,110,0.35)]'
                          : 'bg-teal-50 text-[#0F766E] border border-teal-100'
                      }`}
                    >
                      {step.icon}
                    </div>
                    <span className="text-3xl font-bold font-mono tabular-nums bg-gradient-to-r from-[#115E59] to-[#0D9488] bg-clip-text text-transparent">
                      {step.number}
                    </span>
                  </div>

                  <div className="text-xs font-medium text-[#0F766E] mb-1.5">
                    {step.subtitle}
                  </div>
                  <h3 className="text-xl font-bold text-[#062925] mb-3">
                    {step.title}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-6">
                    {step.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-teal-100/80 flex items-center justify-between text-xs text-slate-500">
                  <span className="font-mono tabular-nums">{step.timeNote}</span>
                  <span className="font-semibold text-[#0F766E]">
                    Step {step.number} of 03
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom Subtle Action Prompt */}
        <div className="mt-12 text-center">
          <button
            type="button"
            onClick={onStartBooking}
            className="px-7 py-3.5 text-sm font-semibold text-[#0F766E] bg-white hover:bg-teal-50/90 border border-teal-200 rounded-full shadow-[0_6px_20px_-4px_rgba(15,118,110,0.14)] transition-all duration-150 cursor-pointer"
          >
            Start Step 01 — Book Your Visit
          </button>
        </div>
      </div>
    </section>
  );
};
