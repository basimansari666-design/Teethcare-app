import React, { useState } from 'react';
import { ShieldCheck, Award, Users, ArrowUpRight } from 'lucide-react';

interface AboutProps {
  onBookConsultation: () => void;
}

export const About: React.FC<AboutProps> = ({ onBookConsultation }) => {
  const [imgError, setImgError] = useState(false);

  return (
    <section
      id="about"
      className="py-20 sm:py-28 relative bg-gradient-to-b from-[#F4FAF9] via-white to-[#EFF9F7]"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
          {/* Left Column: Futuristic Dental Clinic Image & Architectural Frame */}
          <div className="lg:col-span-6 relative">
            <div
              aria-hidden="true"
              className="absolute -inset-3 rounded-3xl bg-gradient-to-tr from-teal-300/35 via-teal-200/25 to-transparent blur-2xl pointer-events-none"
            />
            <div className="relative rounded-2xl overflow-hidden border border-teal-100 shadow-[0_22px_55px_-14px_rgba(15,118,110,0.18)] bg-[#042F2E] aspect-[4/3]">
              {!imgError ? (
                <img
                  src="/src/assets/images/about_dental_suite_1791213101602.jpg"
                  alt="Futuristic TeethCare luxury dental consultation suite with dental specialist reviewing a transparent diagnostic tablet with a patient"
                  referrerPolicy="no-referrer"
                  onError={() => setImgError(true)}
                  className="w-full h-full object-cover object-center transition-transform duration-700 hover:scale-[1.02]"
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center p-8 bg-gradient-to-br from-teal-50 to-emerald-50 text-center">
                  <Users className="w-12 h-12 text-[#0F766E] mb-3" />
                  <p className="text-sm font-bold text-[#062925]">
                    TeethCare Clinical Care Suite
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    Human Expertise Augmented by Precision Robotics
                  </p>
                </div>
              )}

              {/* Subtle Glassmorphic Clinical Standard Overlay */}
              <div className="absolute bottom-4 inset-x-4 rounded-xl bg-white/90 backdrop-blur-md border border-white/95 p-4 shadow-[0_10px_30px_rgba(6,41,37,0.14)] flex items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-teal-600/15 border border-teal-500/30 flex items-center justify-center text-[#0F766E] shrink-0">
                    <ShieldCheck className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-[#062925]">
                      Board-Certified Specialist Oversight
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Every AI diagnostic scan is verified by a senior clinician
                    </div>
                  </div>
                </div>
                <span className="hidden sm:inline-block text-xs font-mono font-semibold text-[#0F766E] tabular-nums shrink-0">
                  ISO-13485 Clinical Grade
                </span>
              </div>
            </div>
          </div>

          {/* Right Column: Editorial Content & Required Statistics */}
          <div className="lg:col-span-6">
            <p className="text-xs font-semibold tracking-wider text-[#0F766E] mb-3">
              About TeethCare · Human-Centered Clinical Innovation
            </p>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-[#062925] leading-[1.12] mb-6">
              A Dental Experience Built for Tomorrow.
            </h2>

            <p className="text-base sm:text-lg text-slate-600 leading-relaxed mb-5">
              TeethCare combines experienced dental professionals with intelligent technology to create a more comfortable, transparent and personalized dental experience.
            </p>

            <p className="text-sm sm:text-base text-slate-600 leading-relaxed mb-8">
              We designed our clinics to eliminate dental anxiety. From whisper-quiet acoustic suites and radiation-free optical imaging to interactive 3D treatment previews, you stay informed and in control at every step of your care.
            </p>

            {/* Required Statistics Row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
              <div className="rounded-2xl bg-white/85 backdrop-blur-md border border-teal-100/90 p-5 shadow-[0_8px_25px_-10px_rgba(15,118,110,0.1)]">
                <div className="text-2xl sm:text-3xl font-bold text-[#062925] tabular-nums tracking-tight mb-1">
                  15+
                </div>
                <div className="text-xs sm:text-sm font-medium text-slate-600">
                  Dental Specialists
                </div>
              </div>

              <div className="rounded-2xl bg-white/85 backdrop-blur-md border border-teal-100/90 p-5 shadow-[0_8px_25px_-10px_rgba(15,118,110,0.1)]">
                <div className="text-2xl sm:text-3xl font-bold text-[#062925] tabular-nums tracking-tight mb-1">
                  10K+
                </div>
                <div className="text-xs sm:text-sm font-medium text-slate-600">
                  Patients
                </div>
              </div>

              <div className="rounded-2xl bg-white/85 backdrop-blur-md border border-teal-100/90 p-5 shadow-[0_8px_25px_-10px_rgba(15,118,110,0.1)]">
                <div className="text-2xl sm:text-3xl font-bold text-[#0F766E] tabular-nums tracking-tight mb-1">
                  4.9/5
                </div>
                <div className="text-xs sm:text-sm font-medium text-slate-600">
                  Patient Rating
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4">
              <button
                type="button"
                onClick={onBookConsultation}
                className="px-6 py-3.5 text-sm font-semibold text-white bg-gradient-to-r from-[#115E59] to-[#0D9488] hover:from-[#0F766E] hover:to-[#14B8A6] rounded-full shadow-[0_8px_24px_-4px_rgba(15,118,110,0.45)] transition-all duration-150 whitespace-nowrap cursor-pointer inline-flex items-center gap-2"
              >
                <span>Meet Your Care Team</span>
                <ArrowUpRight className="w-4 h-4" />
              </button>
              <div className="flex items-center gap-2 text-xs text-slate-500">
                <Award className="w-4 h-4 text-[#0F766E] shrink-0" />
                <span>Harvard & Zurich Trained Prosthodontists & Orthodontists</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
