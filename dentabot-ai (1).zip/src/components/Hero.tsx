import React, { useState } from 'react';
import { ArrowUpRight, Search, Activity, ShieldCheck } from 'lucide-react';

interface HeroProps {
  onBookAppointment: () => void;
  onExploreTechnology: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onBookAppointment,
  onExploreTechnology,
}) => {
  const [imageError, setImageError] = useState(false);
  const [hudOverlayActive, setHudOverlayActive] = useState(true);

  return (
    <section
      id="top"
      className="relative pt-28 sm:pt-32 lg:pt-36 pb-16 sm:pb-24 overflow-hidden bg-gradient-to-b from-[#E6F4F1] via-[#EFF9F7] to-[#F4FAF9]"
    >
      {/* Subtle Ambient Deep Teal Lighting Accents */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-24 left-1/4 w-[38rem] h-[38rem] rounded-full bg-teal-500/15 blur-[130px]"
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute top-1/3 -right-24 w-[34rem] h-[34rem] rounded-full bg-teal-700/15 blur-[120px]"
      />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        {/* Main Cinematic Hero Container */}
        <div className="relative rounded-3xl bg-white/70 backdrop-blur-xl border border-white/90 shadow-[0_24px_80px_-15px_rgba(15,118,110,0.15)] p-6 sm:p-10 lg:p-12 overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
            {/* Left Column: High-Hierarchy Typography, CTAs & Trust Statistics */}
            <div className="lg:col-span-6 z-10 flex flex-col items-start text-left">
              <div className="flex items-center gap-2 text-xs font-semibold tracking-wide text-[#0F766E] mb-4">
                <span className="inline-block w-2 h-2 rounded-full bg-[#0D9488] shadow-[0_0_8px_#0d9488]" />
                <span>Next-Generation Clinical Robotics</span>
                <span aria-hidden="true" className="text-slate-300">·</span>
                <span className="text-slate-500 font-normal">Optical AI Diagnostics</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-[3.5rem] font-bold tracking-tight text-[#062925] leading-[1.08] mb-5">
                Your Futuristic{' '}
                <span className="bg-gradient-to-r from-[#115E59] via-[#0F766E] to-[#0D9488] bg-clip-text text-transparent">
                  AI Dental
                </span>{' '}
                Experience
              </h1>

              <p className="text-base sm:text-lg lg:text-xl text-slate-600 leading-relaxed max-w-xl mb-8 font-normal">
                Friendly, Precise, Painless Dentistry Powered by AI.
              </p>

              {/* Primary CTA & Secondary Circular Action */}
              <div className="flex flex-wrap items-center gap-4 mb-10">
                <button
                  type="button"
                  onClick={onBookAppointment}
                  className="px-7 py-4 text-base font-semibold text-white bg-gradient-to-r from-[#115E59] via-[#0F766E] to-[#0D9488] hover:from-[#0F766E] hover:to-[#14B8A6] rounded-full shadow-[0_10px_30px_-5px_rgba(15,118,110,0.5)] hover:shadow-[0_14px_35px_-3px_rgba(13,148,136,0.65)] transition-all duration-150 whitespace-nowrap cursor-pointer active:scale-[0.99] flex items-center gap-2.5"
                >
                  <span>Book Your Appointment</span>
                  <ArrowUpRight className="w-5 h-5" />
                </button>

                <button
                  type="button"
                  onClick={onExploreTechnology}
                  aria-label="Explore AI Dental Diagnostics"
                  title="Explore AI Dental Diagnostics"
                  className="w-13 h-13 rounded-full bg-white/90 hover:bg-white border border-teal-200/90 text-[#0F766E] hover:text-[#115E59] shadow-[0_8px_24px_-4px_rgba(15,118,110,0.18)] hover:shadow-[0_10px_28px_-2px_rgba(13,148,136,0.3)] flex items-center justify-center transition-all duration-150 cursor-pointer group"
                >
                  <Search className="w-5 h-5 transition-transform duration-150 group-hover:scale-110" />
                </button>
              </div>

              {/* Trust Statistics below the CTA */}
              <div className="w-full pt-7 border-t border-teal-100/90 grid grid-cols-3 gap-4 sm:gap-6">
                <div>
                  <div className="text-2xl sm:text-3xl font-bold text-[#062925] tabular-nums tracking-tight">
                    98%
                  </div>
                  <div className="text-xs sm:text-sm text-slate-500 mt-0.5 font-medium">
                    Diagnostic Accuracy
                  </div>
                </div>

                <div className="border-l border-teal-100/90 pl-4 sm:pl-6">
                  <div className="text-2xl sm:text-3xl font-bold text-[#062925] tabular-nums tracking-tight">
                    24/7
                  </div>
                  <div className="text-xs sm:text-sm text-slate-500 mt-0.5 font-medium">
                    AI Support
                  </div>
                </div>

                <div className="border-l border-teal-100/90 pl-4 sm:pl-6">
                  <div className="text-2xl sm:text-3xl font-bold text-[#062925] tabular-nums tracking-tight">
                    10K+
                  </div>
                  <div className="text-xs sm:text-sm text-slate-500 mt-0.5 font-medium">
                    Happy Patients
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column: Cinematic Futuristic Dental Clinic Visual & Glowing Deep Teal UI Elements */}
            <div className="lg:col-span-6 relative">
              {/* Outer Glowing Deep Teal Frame Halo */}
              <div
                aria-hidden="true"
                className="absolute -inset-2 rounded-3xl bg-gradient-to-tr from-teal-600/25 via-teal-400/15 to-transparent blur-xl pointer-events-none"
              />

              <div className="relative rounded-2xl overflow-hidden border border-white/90 shadow-[0_20px_50px_-12px_rgba(15,118,110,0.25)] bg-gradient-to-br from-[#062925] via-[#042F2E] to-[#08332E] aspect-[16/11] sm:aspect-[16/10]">
                {!imageError ? (
                  <img
                    src="/src/assets/images/hero_dental_clinic_1791213085019.jpg"
                    alt="Futuristic TeethCare dental clinic featuring an AI robotic dental assistant, ergonomic patient chair, and holographic diagnostic screens"
                    referrerPolicy="no-referrer"
                    onError={() => setImageError(true)}
                    className="w-full h-full object-cover object-center transition-transform duration-700 hover:scale-[1.02]"
                  />
                ) : (
                  <div className="w-full h-full flex flex-col items-center justify-center p-8 text-center bg-gradient-to-br from-teal-100 via-teal-50 to-white">
                    <Activity className="w-12 h-12 text-[#0F766E] mb-3" />
                    <p className="text-sm font-semibold text-[#062925]">
                      TeethCare Clinical Suite
                    </p>
                    <p className="text-xs text-slate-500 mt-1">
                      Autonomous Optical Diagnostics & Ergonomic Care
                    </p>
                  </div>
                )}

                {/* Subtle Deep Teal Scrim for UI Readability */}
                <div
                  aria-hidden="true"
                  className="absolute inset-0 bg-gradient-to-t from-[#042F2E]/50 via-[#0F766E]/10 to-[#042F2E]/15 pointer-events-none"
                />

                {/* Animated Glowing Deep Teal Diagnostic Scan Line */}
                {hudOverlayActive && (
                  <div
                    aria-hidden="true"
                    className="absolute inset-x-0 top-0 h-28 bg-gradient-to-b from-teal-400/25 via-teal-300/5 to-transparent border-t border-teal-300/70 animate-scan pointer-events-none"
                  />
                )}

                {/* Top-Left Floating Glass HUD: AI Robotic Calibration */}
                {hudOverlayActive && (
                  <div className="absolute top-3.5 left-3.5 sm:top-4 sm:left-4 bg-white/88 backdrop-blur-md border border-white/90 rounded-xl px-3.5 py-2.5 shadow-[0_8px_24px_rgba(15,118,110,0.2)] flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-teal-600/15 border border-teal-500/30 flex items-center justify-center text-[#0F766E] shrink-0">
                      <Activity className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-[11px] font-medium text-slate-500">
                        Optical Intraoral Scan
                      </div>
                      <div className="text-xs font-bold text-[#062925] tabular-nums">
                        98.7% Mapping Precision
                      </div>
                    </div>
                  </div>
                )}

                {/* Bottom-Right Floating Glass HUD: Patient Comfort Telemetry */}
                {hudOverlayActive && (
                  <div className="absolute bottom-3.5 right-3.5 sm:bottom-4 sm:right-4 bg-white/88 backdrop-blur-md border border-white/90 rounded-xl px-3.5 py-2.5 shadow-[0_8px_24px_rgba(15,118,110,0.22)] flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-teal-600/15 border border-teal-500/30 flex items-center justify-center text-[#0F766E] shrink-0">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="text-[11px] font-medium text-slate-500">
                        AI Comfort Calibration
                      </div>
                      <div className="text-xs font-bold text-[#062925]">
                        Zero-Pain Micro-Laser Ready
                      </div>
                    </div>
                  </div>
                )}

                {/* Interactive HUD Toggle Button */}
                <button
                  type="button"
                  onClick={() => setHudOverlayActive((prev) => !prev)}
                  className="absolute top-3.5 right-3.5 sm:top-4 sm:right-4 px-2.5 py-1 rounded-lg bg-[#042F2E]/75 hover:bg-[#042F2E]/90 backdrop-blur-md text-[11px] font-medium text-teal-200 border border-teal-400/30 transition-colors cursor-pointer"
                >
                  {hudOverlayActive ? 'Hide HUD' : 'Show HUD'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
