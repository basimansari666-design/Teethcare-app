import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

interface NavbarProps {
  onNavigate: (sectionId: string) => void;
  onOpenLogin: () => void;
  loggedInUser: string | null;
}

export const DentalLogoIcon: React.FC<{ className?: string }> = ({ className = 'w-7 h-7' }) => (
  <svg
    viewBox="0 0 36 36"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <defs>
      <linearGradient id="dentabot-logo-grad" x1="4" y1="4" x2="32" y2="32" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#115E59" />
        <stop offset="55%" stopColor="#0F766E" />
        <stop offset="100%" stopColor="#0D9488" />
      </linearGradient>
      <linearGradient id="dentabot-inner-glow" x1="10" y1="8" x2="26" y2="28" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#CCFBF1" />
        <stop offset="100%" stopColor="#99F6E4" />
      </linearGradient>
    </defs>
    {/* Outer rounded medical squircle */}
    <rect
      x="2"
      y="2"
      width="32"
      height="32"
      rx="10"
      fill="url(#dentabot-logo-grad)"
    />
    {/* Precision Tooth Silhouette */}
    <path
      d="M12.5 10.5C10.3 10.5 8.8 12.2 8.8 14.6C8.8 17.5 10.1 20.1 11.1 23.2C11.7 25.1 12.4 26.8 13.6 26.8C14.7 26.8 15.3 24.9 16.1 22.9C16.5 21.9 17.2 21.4 18 21.4C18.8 21.4 19.5 21.9 19.9 22.9C20.7 24.9 21.3 26.8 22.4 26.8C23.6 26.8 24.3 25.1 24.9 23.2C25.9 20.1 27.2 17.5 27.2 14.6C27.2 12.2 25.7 10.5 23.5 10.5C21.8 10.5 20.3 11.4 18.9 11.8C18.3 12 17.7 12 17.1 11.8C15.7 11.4 14.2 10.5 12.5 10.5Z"
      fill="white"
    />
    {/* Subtle AI Diagnostic Scan Node Line */}
    <path
      d="M11.5 16.2H24.5"
      stroke="url(#dentabot-logo-grad)"
      strokeWidth="1.4"
      strokeLinecap="round"
    />
    <circle cx="18" cy="16.2" r="1.8" fill="#0F766E" />
  </svg>
);

export const Navbar: React.FC<NavbarProps> = ({
  onNavigate,
  onOpenLogin,
  loggedInUser,
}) => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 16);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Services', id: 'services' },
    { label: 'About Us', id: 'about' },
    { label: 'AI Technology', id: 'technology' },
    { label: 'Contact', id: 'contact' },
  ];

  const handleNavClick = (id: string) => {
    setMobileMenuOpen(false);
    onNavigate(id);
  };

  return (
    <header className="fixed top-3 sm:top-5 inset-x-0 z-50 px-4 sm:px-6 lg:px-8 pointer-events-none">
      <div
        className={`mx-auto max-w-7xl pointer-events-auto transition-all duration-200 rounded-2xl border ${
          scrolled
            ? 'bg-white/85 backdrop-blur-xl border-teal-200/80 shadow-[0_12px_36px_-8px_rgba(15,118,110,0.14)] py-3 px-4 sm:px-6'
            : 'bg-white/75 backdrop-blur-lg border-white/90 shadow-[0_8px_30px_rgba(15,118,110,0.08)] py-3.5 px-4 sm:px-6'
        }`}
      >
        <div className="flex items-center justify-between gap-4">
          {/* Zone 1: Brand Title (Single clean wordmark element with icon) */}
          <a
            href="#top"
            onClick={(e) => {
              e.preventDefault();
              handleNavClick('top');
            }}
            className="flex items-center gap-2.5 text-xl font-bold tracking-tight focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 rounded-lg shrink-0"
          >
            <DentalLogoIcon className="w-8 h-8 shrink-0" />
            <span className="text-[#062925]">
              Teeth<span className="text-[#0F766E]">Care</span>
            </span>
          </a>

          {/* Zone 2: Center Navigation Links */}
          <nav
            aria-label="Primary Navigation"
            className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600"
          >
            {navItems.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(item.id);
                }}
                className="relative py-1 text-slate-700 hover:text-[#0F766E] transition-colors duration-150 whitespace-nowrap after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-gradient-to-r after:from-[#115E59] after:to-[#0D9488] hover:after:w-full after:transition-all after:duration-200"
              >
                {item.label}
              </a>
            ))}
          </nav>

          {/* Zone 3: Primary Actions */}
          <div className="hidden md:flex items-center gap-3 shrink-0">
            <button
              type="button"
              onClick={onOpenLogin}
              className="px-4 py-2 text-sm font-medium text-slate-700 hover:text-[#0F766E] transition-colors duration-150 whitespace-nowrap rounded-full focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-600 cursor-pointer"
            >
              {loggedInUser ? `Portal (${loggedInUser})` : 'Log In'}
            </button>
            <button
              type="button"
              onClick={() => handleNavClick('appointment')}
              className="px-5 py-2.5 text-sm font-semibold text-white bg-gradient-to-r from-[#115E59] via-[#0F766E] to-[#0D9488] hover:from-[#0F766E] hover:to-[#14B8A6] rounded-full shadow-[0_6px_20px_-3px_rgba(15,118,110,0.45)] hover:shadow-[0_8px_25px_-2px_rgba(13,148,136,0.6)] transition-all duration-150 whitespace-nowrap cursor-pointer active:scale-[0.99]"
            >
              Book Appointment
            </button>
          </div>

          {/* Mobile Hamburger Control */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen((prev) => !prev)}
            aria-label={mobileMenuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileMenuOpen}
            className="md:hidden p-2.5 rounded-xl text-slate-700 hover:text-[#0F766E] hover:bg-teal-50/80 transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-teal-600"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile Dropdown Drawer */}
        {mobileMenuOpen && (
          <div className="md:hidden mt-3 pt-3 border-t border-teal-100/90 flex flex-col gap-1.5">
            {navItems.map((item) => (
              <a
                key={item.id}
                href={`#${item.id}`}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(item.id);
                }}
                className="px-3.5 py-2.5 rounded-xl text-sm font-medium text-slate-700 hover:text-[#0F766E] hover:bg-teal-50/70 transition-colors"
              >
                {item.label}
              </a>
            ))}
            <div className="pt-2 mt-1 border-t border-teal-100/70 flex flex-col sm:flex-row gap-2.5">
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenLogin();
                }}
                className="w-full py-2.5 px-4 text-sm font-medium text-slate-700 bg-teal-50/80 hover:bg-teal-100/80 rounded-full transition-colors text-center"
              >
                {loggedInUser ? `Patient Portal (${loggedInUser})` : 'Log In'}
              </button>
              <button
                type="button"
                onClick={() => handleNavClick('appointment')}
                className="w-full py-2.5 px-5 text-sm font-semibold text-white bg-gradient-to-r from-[#115E59] to-[#0D9488] rounded-full shadow-[0_6px_20px_-3px_rgba(15,118,110,0.45)] text-center"
              >
                Book Appointment
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
