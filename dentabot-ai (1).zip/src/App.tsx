/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { Technology } from './components/Technology';
import { About } from './components/About';
import { HowItWorks } from './components/HowItWorks';
import { Testimonials } from './components/Testimonials';
import { Appointment } from './components/Appointment';
import { Footer } from './components/Footer';
import { LoginModal, InfoModal } from './components/LoginModal';

export default function App() {
  const [preselectedService, setPreselectedService] = useState<string>('AI Dental Scan');
  const [loginModalOpen, setLoginModalOpen] = useState<boolean>(false);
  const [loggedInUser, setLoggedInUser] = useState<string | null>(null);
  const [infoModalTopic, setInfoModalTopic] = useState<'FAQ' | 'Privacy Policy' | 'Terms' | 'Careers' | null>(null);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } else if (sectionId === 'top') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleSelectServiceForBooking = (serviceTitle: string) => {
    setPreselectedService(serviceTitle);
    scrollToSection('appointment');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#F4FAF9] text-[#062925] selection:bg-teal-700/20 selection:text-teal-950">
      {/* 1. Floating Glassmorphism Navigation Bar */}
      <Navbar
        onNavigate={scrollToSection}
        onOpenLogin={() => setLoginModalOpen(true)}
        loggedInUser={loggedInUser}
      />

      <main className="flex-grow">
        {/* 2. Cinematic Hero Section */}
        <Hero
          onBookAppointment={() => scrollToSection('appointment')}
          onExploreTechnology={() => scrollToSection('technology')}
        />

        {/* 3. Services Section */}
        <Services
          onSelectServiceForBooking={handleSelectServiceForBooking}
        />

        {/* 4. AI Technology Section with Interactive Dental Diagnostic Visualization */}
        <Technology
          onBookScan={() => handleSelectServiceForBooking('AI Dental Scan')}
        />

        {/* 5. About Us Section */}
        <About
          onBookConsultation={() => handleSelectServiceForBooking('AI Dental Consultation')}
        />

        {/* 6. How It Works (3-Step Clinical Pathway) */}
        <HowItWorks
          onStartBooking={() => scrollToSection('appointment')}
        />

        {/* 7. Patient Experience (Testimonials) Section */}
        <Testimonials />

        {/* 8. Appointment Section with Validated Form */}
        <Appointment
          preselectedService={preselectedService}
        />
      </main>

      {/* 9. Premium Clean Footer */}
      <Footer
        onNavigate={scrollToSection}
        onSelectService={handleSelectServiceForBooking}
        onOpenInfoModal={(topic) => setInfoModalTopic(topic)}
      />

      {/* Interactive Patient Portal Login Modal */}
      <LoginModal
        isOpen={loginModalOpen}
        onClose={() => setLoginModalOpen(false)}
        onSuccessLogin={(userName) => setLoggedInUser(userName)}
      />

      {/* Interactive Support & Company Info Modal */}
      <InfoModal
        topic={infoModalTopic}
        onClose={() => setInfoModalTopic(null)}
      />
    </div>
  );
}
